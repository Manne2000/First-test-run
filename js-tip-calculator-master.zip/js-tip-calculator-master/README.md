# js-tip-calculator
A very basic frontend only website to calculate tip on a bill.
